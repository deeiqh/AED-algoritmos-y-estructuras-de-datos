#include<iostream>

using namespace std;

template<class T>
class Nodo
{
     public:
        Nodo<T>  * m_pSig;
             T     m_Dato;
     public:
       Nodo(T d)
       { 
          m_pSig = NULL;
          m_Dato = d;
       }  
};

template<class T>
class List
{   
    typedef Nodo<T>  * pNodo;
    private:
       pNodo m_pHead;
       pNodo m_pLast;
    public:
       List()
       { 
         m_pHead = NULL;
         m_pLast = NULL;
       } 
      
      void push_front(T d)
      {
        pNodo pNuevo   =  new Nodo<T>(d);
        if ( !m_pHead )
			    m_pHead = m_pLast = pNuevo;
        else{
          pNuevo->m_pSig = m_pHead;
				  m_pHead = pNuevo;
        } 
      }


    	void push_back(T d){
    		pNodo pNuevo   =  new Nodo<T>(d);
               if ( !m_pHead )
    				m_pHead = m_pLast = pNuevo;
               else
    			{
    				m_pLast->m_pSig = pNuevo;
    				m_pLast=pNuevo;	
                } 
    	}

      void pop_front(){
    	  if(!m_pHead) return;	
          pNodo temp = m_pHead;
          m_pHead = m_pHead->m_pSig;
          delete temp;
      }
    	void pop_back()
       {
    		if(!m_pHead) return;
    		if(m_pHead == m_pLast) 
    		{ 
    		  delete m_pHead; 
    		  m_pHead = m_pLast = NULL;
    		} 
    		pNodo tmp = m_pHead;
    		for(  ; tmp->m_pSig!=m_pLast; tmp = tmp->m_pSig);
    		delete m_pLast;
    		m_pLast = tmp;
      }
        
      void add(T d)
      {
        Nodo<T>* lista = this->m_pHead;
        add_(d,lista);
      }

      void add_(T d, Nodo<T> * & p)
      {
            if(!p) {p = new Nodo<T>(d); return;}
            add_(d, p->m_pSig);
      }    

      void show(ostream &os)
      {
        Nodo<T>* lista = this->m_pHead;
        while(lista != NULL){
          os << lista->m_Dato << " -> ";
          lista = lista->m_pSig;
        }
        os << "NULL\n";
      }

      void show_r(ostream &os)
      {
        Nodo<T>* lista = this->m_pHead;
        show_r_(os,lista);

      }

      void show_r_(ostream &os, Nodo<T>* lista)
      {
        if(lista == NULL)
          os << "NULL\n";
        else{
          os << lista->m_Dato << " -> ";
          lista = lista->m_pSig;
          show_r_(os, lista);
        }        
      }

      bool find(T dato)
      {
        Nodo<T>* lista = this->m_pHead;
        while(lista != NULL){
          if(lista->m_Dato == dato)
            return true;
          else
            lista = lista->m_pSig;
        }
        return false;
      }

      bool find_r(T dato)
      {
        Nodo<T>* lista = this->m_pHead;
        find_r_(dato, lista);
      }

      bool find_r_( T dato, Nodo<T>* lista)
      {
        if(lista == NULL)
          return false;
        else          
          if(lista->m_Dato == dato)
            return true;
          else{
            lista = lista->m_pSig;
            return find_r_(dato, lista);
          }
      }
      

}; 

template<class T>
class DNodo
{
     public:
        DNodo<T>  * m_pSig;
        DNodo<T>* m_pAnt;
             T     m_Dato;
     public:
       DNodo(T d)
       { 
          m_pSig = NULL;
          m_pAnt = NULL;
          m_Dato = d;
       }  
};

template<class T>
class DList
{   
    typedef DNodo<T>  * pNodo;
    private:
       pNodo m_pHead;
       pNodo m_pLast;
    public:
       DList()
       { 
         m_pHead = NULL;
         m_pLast = NULL;
       } 
      
      void push_front(T d)
      {
        pNodo pNuevo   =  new DNodo<T>(d);
        if ( !m_pHead )
          m_pHead = m_pLast = pNuevo;
        else{
          pNuevo->m_pSig = m_pHead;
          m_pHead = pNuevo;
        } 
      }


      void push_back(T d){
        pNodo pNuevo   =  new DNodo<T>(d);
        if ( !m_pHead )
            m_pHead = m_pLast = pNuevo;
        else
          {
            m_pLast->m_pSig = pNuevo;
            pNuevo->m_pAnt = m_pLast;
            m_pLast=pNuevo; 
          } 
      }

      void show(ostream &os)
      {
        DNodo<T>* lista = this->m_pHead;
        while(lista != NULL){
          os << lista->m_Dato << " -> ";
          lista = lista->m_pSig;
        }
        os << "NULL\n";
      }

      void pop_front(){
        if(!m_pHead) return;  
          pNodo temp = m_pHead;
          m_pHead->m_pSig->m_pAnt = NULL;
          m_pHead = m_pHead->m_pSig;
          delete temp;
      }

      void pop_back()
       {
        if(!m_pHead) return;
        if(m_pHead == m_pLast) 
        { 
          delete m_pHead; 
          m_pHead = m_pLast = NULL;
        } 
        pNodo tmp = m_pHead;
        for(  ; tmp->m_pSig!=m_pLast; tmp = tmp->m_pSig);
        delete m_pLast;
        m_pLast = tmp;
        m_pLast->m_pSig = NULL;
      }

      void add_r(T d)
      {
        pNodo lista = this->m_pHead;
        pNodo ant = NULL;
        add_r_(d,ant,lista);
      }

      void add_r_(T d, pNodo ant, pNodo & p)
      {
            if(!p) {p = new DNodo<T>(d); p->m_pAnt = ant; return;}
            add_r_(d, ant = p ,p->m_pSig);
      }    

      bool find_r(T dato)
      {
        pNodo lista = this->m_pHead;
        find_r_(dato, lista);
      }

      bool find_r_( T dato, pNodo lista)
      {
        if(lista == NULL)
          return false;
        else          
          if(lista->m_Dato == dato)
            return true;
          else{
            lista = lista->m_pSig;
            return find_r_(dato, lista);
          }
      }


}; 

int main()
{
    List<int>  A;
    A.push_front(5);
    A.push_front(15);
    A.push_front(25);
    A.push_front(35);
    A.add(1);
  
    A.show_r(cout);

    cout << A.find_r(350) << '\n';

    DList<int> B;

    B.push_back(1);
    B.push_back(2);
    B.show(cout);

    B.pop_front();
    B.show(cout);
    B.push_back(3);
    B.show(cout);

    B.pop_back();
    B.show(cout);

    B.add_r(3);
    B.add_r(4);
    B.show(cout);

    cout << B.find_r(3) << '\n';


    return 1;
}

