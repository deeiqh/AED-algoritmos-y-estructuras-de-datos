#include <iostream>

using namespace std;

template <class T>
class LNodo{
public:
	T dato;
	LNodo* next;
public:
	LNodo(): next(NULL){}
	LNodo(T dato): dato(dato), next(NULL){}
};

template <class T>
class Lista{
public:
	LNodo<T>* head;
public:
	Lista():head(NULL) {}

	LNodo<T>** find(T dato){
		LNodo<T>** r = &head;
		while(*r != NULL && (*r)->dato < dato){
			r = &((*r)->next);
		}
		return r;
	}

	void add_ordenado(T dato){
		LNodo<T>** f = find(dato);
		if((*f) != NULL && ((*f)->dato == dato)){
			return;
		}
		LNodo<T>* pNodo = new LNodo<T>(dato);
		pNodo->next = *f;
		*f = pNodo;
	}

	void del(T dato){
		LNodo<T>** f = find(dato);
		if((*f) != NULL && ((*f)->dato == dato)){
			LNodo<T>* temp = *f;
			*f = (*f)->next;
			delete temp;
		}
	}

	void show(){
		LNodo<T>* t = head;
		while( t != NULL){
			cout << t->dato <<  " -> ";
			t = t->next;
		}
		cout << "NULL\n";
	}
};

int main()
{		
	Lista<int>* l = new Lista<int>();

	l->add_ordenado(0);
	l->add_ordenado(7);
	l->add_ordenado(10);
	l->add_ordenado(9);
	l->add_ordenado(3);
	l->add_ordenado(10);
	l->add_ordenado(-1);
	l->add_ordenado(10);
	l->add_ordenado(10);
	l->show();

	l->del(10);
	l->del(7);
	l->del(-1);
	l->show();

	delete l;





	return 0;
}