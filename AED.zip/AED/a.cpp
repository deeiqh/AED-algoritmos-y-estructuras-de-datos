#include <iostream>

using namespace std;

int main()
{
	int a;

	int*b_;
	b_= &a;
	int**b = &b_; // b es un puntero a una variable, no funca si se hace &&a
					// ..."como es una variable le puedo asignar un puntero"



	int b__;

	int*c = &b__; 

	int**d = &c;

	a = 3;

	cout << **b << '\n';

	return 0;
}