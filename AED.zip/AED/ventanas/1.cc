#include<gtkmm.h>

int main()
{
	auto app = Gtk::Aplication::create("app");

	Gtk::Window window;
	window.set_default_size(200,200);

	return app->run(window);
}