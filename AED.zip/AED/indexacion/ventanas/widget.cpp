#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}
#include "dato.h"
#include "lista_doble.h"
#include <string>
#include <fstream>

using namespace std;

using DatoSUI = Dato<string, unsigned int>;

#define nombre_archivo "enfermedades.txt"
void Widget::on_pushButton_clicked()
{
    ListaD<DatoSUI>* pLista = new ListaD<DatoSUI>;

    string nombre="";
    char c[1];
    unsigned int pos=0;
    bool flag = true;

    fstream arch;
    arch.open(nombre_archivo, fstream::in | fstream::out);
    arch.read(c,1);
    pos++;
    QString s=c[0];
    //String s_(s);

    ui->textBrowser->setText(s);
}
