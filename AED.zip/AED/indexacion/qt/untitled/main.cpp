#include "widget.h"
#include <QApplication>

#include "dato.h"
#include "lista_doble.h"
#include <string>
#include <fstream>


using namespace std;

using DatoSUI = Dato<string, unsigned int>;

#define nombre_archivo "enfermedades.txt"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();

    ListaD<DatoSUI>* pLista = new ListaD<DatoSUI>;

    string nombre="";
    char c[1];
    unsigned int pos=0;
    bool flag = true;;

    fstream arch;
    arch.open(nombre_archivo, fstream::in | fstream::out);
    arch.read(c,1);
    pos++;
    while(c[0] != '~'){
        while(c[0] != '#'){
            nombre += c[0];
            arch.read(c,1);
            pos++;
        }
        arch.read(c,1);
        pos++;
        if(c[0] == '0')
            flag = false;
        arch.read(c,1);
        pos++;
        if(flag){
            DatoSUI dato(nombre,pos);
            pLista->add_ordenado(dato);
        }
        nombre = "";
        while(c[0] != '@'){
            arch.read(c,1);
            pos++;
        }
        arch.read(c,1);
        pos++;
        flag = true;
    }





    return a.exec();
}
