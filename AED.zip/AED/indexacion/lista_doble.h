#ifndef LISTA_DOBLE_H
#define LISTA_DOBLE_H

template <class T>
class NodoD{
public:
	T dato;
	NodoD* next;
	NodoD* prev;
public:
	NodoD(): next(NULL), prev(NULL) {};
	NodoD(T dato): dato(dato) {};
};

template <class T>
class ListaD{
public:
	NodoD<T>* head;
	NodoD<T>* last;
public:
	ListaD(): head(NULL), last(NULL) {};
	~ListaD(){
		NodoD<T>* temp1 = head;
		NodoD<T>* temp2 = head;
		while(temp1 != NULL){
			temp2 = temp1->next;
			delete temp1;
			temp1 = temp2;
		}
	}

	void show(){
		NodoD<T>* temp = head;
		while(temp != NULL){
			temp->dato.show();
			cout << " -> ";
			temp = temp->next;
		}
		cout << "NULL" << '\n';
	}

	bool find(T dato, NodoD<T>* &pNodo){
		pNodo = head;		
		while( pNodo != NULL && ((pNodo->dato).comp(dato) < 0 ) ){
			pNodo = pNodo->next;
		}
		if( pNodo != NULL && ((pNodo->dato).comp(dato) == 0) ){
			return true;
		}
		return false;
	}

	void add_ordenado(T dato){
		NodoD<T>* pNodo;
		if(!find(dato, pNodo)){
			NodoD<T>* pNodo2 = new NodoD<T>(dato);
			pNodo2->next = pNodo;
			if(pNodo == NULL){
				if(head == NULL){
					head = pNodo2;
					last = pNodo2;
				}
				else{
					pNodo2 -> prev = last;
					last->next = pNodo2;
					last = pNodo2;
				}
			}else{
				if(pNodo == head){
					head->prev = pNodo2;
					head = pNodo2;
				}
				else{
					pNodo2->prev = pNodo->prev;
					pNodo->prev = pNodo2;
					pNodo2->prev->next = pNodo2;
				}
			}

		}
	}

	void del(T dato){
		NodoD<T>* pNodo;
		if(find(dato, pNodo)){
			if(pNodo != NULL){
				if(head == last){
					delete pNodo;
					head = NULL;
					last = NULL;
				}
				else{
					if(pNodo == head){					
						head = pNodo->next;
						head->prev = NULL;
						delete pNodo;
					}
					else{
						if(pNodo == last){
							last = pNodo->prev;
							last->next = NULL;
							delete pNodo;
						}		
						else{
							pNodo->prev->next = pNodo->next;
							pNodo->next->prev = pNodo->prev;
							delete pNodo;
						}
					}
				}
			}
		}
	}

	NodoD<T>* first(){
		return head;
	}

	NodoD<T>* lastt(){
		return last;
	}

	NodoD<T>* next(NodoD<T>* pNodo){
		return pNodo->next;
	}

	NodoD<T>* prev(NodoD<T>* pNodo){
		return pNodo->prev;
	}

};


#endif